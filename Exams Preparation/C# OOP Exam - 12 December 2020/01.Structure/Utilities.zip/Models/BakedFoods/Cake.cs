﻿namespace Bakery.Models.BakedFoods
{
    public class Cake : BakedFood
    {
        private const int InitialCakePortion = 245;
        public Cake(string name, int portion, decimal price) : base(name, 245, price)
        {
        }
    }
}
