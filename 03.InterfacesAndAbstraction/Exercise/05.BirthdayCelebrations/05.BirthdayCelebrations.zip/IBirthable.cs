﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _05.BirthdayCelebrations
{
    interface IBirthable
    {
        string Name { get; }
        string Birthdate { get; }
    }
}
